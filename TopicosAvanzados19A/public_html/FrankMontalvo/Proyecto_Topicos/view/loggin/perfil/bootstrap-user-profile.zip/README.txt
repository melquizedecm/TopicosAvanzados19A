A Pen created at CodePen.io. You can find this one at https://codepen.io/cosme-maga-a-camara/pen/aMxmNz.

 Bootstrap User Profile