<?php

//Cargamos el Iniciador.php de la carpeta BackEnd.
require_once '../BackEnd/Iniciador.php';

//Instanciamos el clase controlador.
$iniciar = new Core;
