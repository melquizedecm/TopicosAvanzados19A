<?php

//Configuracion de acceso a la base de datos.
define('BD_HOST', 'localhost');
define('BD_USUARIO', 'root');
define('BD_PASSWORD', '');
define('BD', 'viniadelmar');

//Ruta de la aplicacion.
define('RUTA_APP', dirname(dirname(__FILE__)));

//Ruta url Ejemplo: 
define('RUTA_URL', 'http://localhost/Restaurante/FrontEnd');

define('NOMBRESITIO', '_NOMBRE_SITIO');
